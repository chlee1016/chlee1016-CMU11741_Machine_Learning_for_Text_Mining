from pmf import PMF
import numpy as np
import utils

path_data = 'C:\\Users\\chlee\\PycharmProjects\\ML_Text_Mining_HW2\\hw2-handout\\data\\train.csv'
data = utils.load_raw_review_data(path_data)

print('Total number of movies :', len(np.unique(data[0])))
print('Total number of users :', len(np.unique(data[1])))

movies = np.asarray(list(data[0]))
users = np.asarray(list(data[1]))
ratings = np.asarray(list(data[2]))

print('len(movies)', len(movies))
print('len(users)', len(users))
print('len(ratings)', len(ratings))

pmf = PMF(100, len(np.unique(data[1])), len(np.unique(data[0])))
alpha = 0.01
lambda_u = 0.01
lambda_v = 0.01
batch_size = 100
num_iterations = 50
pmf.train(users, movies, ratings, alpha, lambda_u, lambda_v, batch_size, num_iterations)