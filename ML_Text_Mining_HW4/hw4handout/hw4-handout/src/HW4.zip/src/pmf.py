import numpy as np


class PMF(object):
    """PMF

    :param object:
    """

    def __init__(self, num_factors, num_users, num_movies):
        """__init__

        :param num_factors:
        :param num_users:
        :param num_movies:
        """
        # note that you should not modify this function
        np.random.seed(11)
        self.U = np.random.normal(size=(num_factors, num_users))
        self.V = np.random.normal(size=(num_factors, num_movies))
        self.num_users = num_users
        self.num_movies = num_movies

    def predict(self, user, movie):
        """predict

        :param user:
        :param movie:
        """
        # note that you should not modify this function
        return (self.U[:, user] * self.V[:, movie]).sum()

    def train(self, users, movies, ratings, alpha, lambda_u, lambda_v,
              batch_size, num_iterations):

        """train

        :param users: np.array of shape [N], type = np.int64
        :param movies: np.array of shape [N], type = np.int64
        :param ratings: np.array of shape [N], type = np.float32
        :param alpha: learning rate
        :param lambda_u:
        :param lambda_v:
        :param batch_size:
        :param num_iterations: how many SGD iterations to run
        """
        # modify this function to implement mini-batch SGD
        # for the i-th training instance,
        # user `users[i]` rates the movie `movies[i]`
        # with a rating `ratings[i]`.

        total_training_cases = users.shape[0]
        for i in range(num_iterations):
            start_idx = (i * batch_size) % total_training_cases
            users_batch = users[start_idx:start_idx + batch_size]
            movies_batch = movies[start_idx:start_idx + batch_size]
            ratings_batch = ratings[start_idx:start_idx + batch_size]
            curr_size = ratings_batch.shape[0]

            # TODO: implement your SGD here!!
            # print(i, 'th iteration')
            # print('ratings')
            # print('movies', movies)
            # print('len(movies)', len(movies))
            # print('users', users)
            # print('len(users)', len(users))
            set_users = set(users)
            # print('set_users', set_users)
            set_movies = set(movies)
            # print('set_movies', set_movies)
            set_users_batch = set(users_batch)
            # print('set_users_batch', set_users_batch)
            set_movies_batch = set(movies_batch)
            # print('set_movies_batch', set_movies_batch)

            # i, j, k is needed to be defined for userID, movieID, and ratingID respectively.
            # i, j means the number of times in the user set, movie set,
            # k is the index of rating correspond to the userID and movieID.


            # print('list(set_users)', list(set_users))
            for user_id in list(set_users_batch):
                # print('user_id', user_id)
                # print('set_users', set_users)
                # print('np.where(list(set_users) == user_id)',np.where(list(set_users) == user_id))
                i = np.squeeze(np.where(list(set_users) == user_id)[0])
                # print('i', i)
                for movie_id in list(set_movies_batch):
                    j = np.squeeze(np.where(list(set_movies) == movie_id)[0])
                    # print('j', j)
                    # print(sum(np.logical_and((users == user_id), (movies == movie_id))))


                    # print('np.logical_and((users == user_id), (movies == movie_id))', np.logical_and((users == user_id), (movies == movie_id)))
                    k = np.squeeze(np.where(np.logical_and((users == user_id), (movies == movie_id)))[0])
                    # print('type(k)', type(k))
                    if k.size != 0:
                        # print('movie_id, user_id', movie_id, user_id)
                        # print('k', k)
                        # print('ratings[k]', ratings[k])
                        # print('U[:,i]', self.U[:, i].shape)
                        # print('V[:,j]', self.V[:, j].shape)
                        # print('ratings', ratings)
                        # print('len(ratings)', len(ratings))
                        # print('ratings[k]', ratings[k])
                        # dU = np.dot(self.V[:, j], np.dot(self.U[:, i].T, self.V[:, j])) + lambda_u * self.U[:, i]
                        dU = (np.dot(self.U[:, i].T, self.V[:, j]) - ratings[k]) * self.V[:, j] + lambda_u * self.U[:, i]
                        # print('self.U[:,i].shape', self.U[:,i].shape)
                        # print('dU.shape', dU.shape)
                        dV = (np.dot(self.V[:, i].T, self.V[:, j]) - ratings[k]) * self.U[:, i]  + lambda_v * self.V[:, j]
                        self.U[:, i] = self.U[:, i] - alpha * dU
                        self.V[:, j] = self.V[:, j] - alpha * dV

