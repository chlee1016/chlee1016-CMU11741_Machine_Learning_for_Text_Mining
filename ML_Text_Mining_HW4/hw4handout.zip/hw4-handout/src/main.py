import sys

from sklearn.datasets import load_svmlight_file

import conjugateGradient as cg


def main():
    # read the train file from first arugment
    train_file = sys.argv[1]

    # read the test file from second argument
    test_file = sys.argv[2]

    # You can use load_svmlight_file to load data from train_file and test_file
    # X_train, y_train = load_svmlight_file(train_file)

    # You can use cg.ConjugateGradient(X, I, grad, lambda_)


# Main entry point to the program
if __name__ == '__main__':
    main()
